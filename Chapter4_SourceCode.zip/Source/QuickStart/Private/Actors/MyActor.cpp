/**********************************************************************************
Copyright 2022 Dr. Chihming Chiu - All Right Reserved

The source code contained within this file is for the book,
UNREAL ENGINE 5 RPG DEVELOPMENT with C++ and Blueprint,
and is intended for educational purposes only.

Feel free to use this code provided you include the above copyright notice.
The code is provided "AS IS", without warranty of any kind, express or implied.
***********************************************************************************/
#include "Actors/MyActor.h"

// Sets default values
AMyActor::AMyActor()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	//PrimaryActorTick.bCanEverTick = true;

}

// Called when the game starts or when spawned
void AMyActor::BeginPlay()
{
	Super::BeginPlay();
	
}

// Called every frame
//void AMyActor::Tick(float DeltaTime)
//{
//	Super::Tick(DeltaTime);
//
//}

