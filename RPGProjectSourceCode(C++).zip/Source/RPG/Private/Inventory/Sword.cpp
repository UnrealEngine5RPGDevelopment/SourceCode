/**********************************************************************************
Copyright � 2022 Dr. Chihming Chiu - All Right Reserved

The source code contained within this file is for the book,
UNREAL ENGINE 5 RPG DEVELOPMENT with C++ and Blueprint,
and is intended for educational purposes only.

Feel free to use this code provided you include the above copyright notice.
The code is provided "AS IS", without warranty of any kind, express or implied.
***********************************************************************************/
#include "NPC/Wolf.h"
#include "Inventory/Sword.h"
#include "Kismet/KismetSystemLibrary.h"
#include "Interfaces/Health.h"
#include "Characters/RPGCharacter.h"

ASword::ASword()
{
	Mesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("SwordMesh"));
	Mesh->SetupAttachment(RootComponent);
	Mesh->OnComponentBeginOverlap.AddDynamic(this, &ASword::OnSwordBeginOverlap);

	SwordTrail = CreateDefaultSubobject<UNiagaraComponent>(TEXT("SwordTrail"));
	SwordTrail->SetupAttachment(Mesh, "TraceEnd");

	ImpactFX =	CreateDefaultSubobject<UNiagaraComponent>(TEXT("ImpactNiagara"));
	ImpactFX->SetupAttachment(Mesh);
}

void ASword::ActivateSwordTrail(bool activate)
{
	if (SwordTrail && SwordTrail->GetAsset()) {
		if (activate)  
			SwordTrail->Activate(true);
		else       
			SwordTrail->Deactivate();
	}
}

void ASword::OnSwordBeginOverlap(UPrimitiveComponent* OverlappedComp,
	AActor* OtherActor, UPrimitiveComponent* OtherComp,
	int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult)
{
	AWolf* enemy = Cast<AWolf>(OtherActor);

	if (enemy) {
		FVector traceStart = Mesh->GetSocketLocation("TraceStart");
		FVector traceEnd = Mesh->GetSocketLocation("TraceEnd");

		FHitResult Hit(ForceInit);
		TArray< FHitResult> HitArray;

		FCollisionQueryParams CollisionParams;
		CollisionParams.AddIgnoredActor(Owner);
		TArray<AActor*> ActorsToIgnore;
		ActorsToIgnore.Add(Owner);

		bool isHit = UKismetSystemLibrary::SphereTraceMulti(GetWorld(),
			traceStart, traceEnd, TraceRadius,
			UEngineTypes::ConvertToTraceType(ECC_Visibility), false,

			ActorsToIgnore, EDrawDebugTrace::ForDuration, HitArray,
			true, FLinearColor::Gray, FLinearColor::Blue, 1.0f);

		if (isHit)
		{
			for (const FHitResult HitResult : HitArray) {
				IHealth* health = Cast<IHealth>(HitResult.GetActor());

				if (health && !health->IsDead()) {
					FName boneName = HitResult.BoneName;

					if (ImpactFX && ImpactFX->GetAsset()) {
						ImpactFX->SetWorldLocation(HitResult.ImpactPoint);
						ImpactFX->Activate();
					}

					ARPGCharacter* player = Cast<ARPGCharacter>(Owner);

					if (Stats) {
						if (player) {
							int damage = Stats->AttackPower->Roll() + player->Stats->GetStatValue(TEXT("STR"));
							health->ApplyDamage(damage, Owner);
						}
						else
							health->ApplyDamage(Stats->AttackPower->Roll(), Owner);
					}
				}
			}
		} // if isHit
	}
}
