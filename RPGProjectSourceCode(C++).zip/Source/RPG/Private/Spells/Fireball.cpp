/**********************************************************************************
Copyright � 2022 Dr. Chihming Chiu - All Right Reserved

The source code contained within this file is for the book,
UNREAL ENGINE 5 RPG DEVELOPMENT with C++ and Blueprint,
and is intended for educational purposes only.

Feel free to use this code provided you include the above copyright notice.
The code is provided "AS IS", without warranty of any kind, express or implied.
***********************************************************************************/
#include "Spells/Fireball.h"
#include "Interfaces/Health.h"

AFireball::AFireball()
{
	if (!RootComponent)
	{
		RootComponent = CreateDefaultSubobject<USceneComponent>(
			TEXT("ProjectileSceneComponent"));
	}

	if (!SphereCollider)
	{
		SphereCollider =
			CreateDefaultSubobject<USphereComponent>(TEXT("SphereComponent"));

		RootComponent = SphereCollider;
	}

	if (!ProjectileMovement)
	{
		ProjectileMovement = CreateDefaultSubobject<UProjectileMovementComponent>(TEXT("ProjectileMovementComponent"));
		ProjectileMovement->SetUpdatedComponent(SphereCollider);
		ProjectileMovement->InitialSpeed = 0;
		ProjectileMovement->ProjectileGravityScale = 0;
	}

	FireballFX =
		CreateDefaultSubobject<UNiagaraComponent>(FName("NiagaraComponent"));
	FireballFX->SetupAttachment(RootComponent);
	
	SphereCollider->OnComponentBeginOverlap.AddDynamic(this, &AFireball::OnSphereColliderBeginOverlap);
}

void AFireball::OnSphereColliderBeginOverlap(UPrimitiveComponent*
	OverlappedComp, AActor* OtherActor, UPrimitiveComponent* OtherComp,
	int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult)
{
	if (OtherActor != Owner && OtherActor->GetOwner() != Owner) {
		IHealth* health = Cast<IHealth>(OtherActor);

		if (health && !health->IsDead()) {
			if (Stats)
				health->ApplyDamage(Stats->AttackPower->Roll(), Owner);
		}

		this->Destroy();
	}
}
