/**********************************************************************************
Copyright � 2022 Dr. Chihming Chiu - All Right Reserved

The source code contained within this file is for the book,
UNREAL ENGINE 5 RPG DEVELOPMENT with C++ and Blueprint,
and is intended for educational purposes only.

Feel free to use this code provided you include the above copyright notice.
The code is provided "AS IS", without warranty of any kind, express or implied.
***********************************************************************************/
#include "Animation/FootstepAnimNotify.h"
#include "PhysicalMaterials/PhysicalMaterial.h"
#include "Kismet/GameplayStatics.h"
#include "Characters/RPGCharacter.h"

void UFootstepAnimNotify::Notify(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
	AActor* owner = MeshComp->GetOwner();
	FVector traceStart = owner->GetActorLocation();
	FVector traceEnd = owner->GetActorLocation() - FVector(0, 0, 150);
	// The hit result	
	FHitResult Hit(ForceInit);
	FCollisionQueryParams CollisionParams;
	CollisionParams.bReturnPhysicalMaterial = true;
	CollisionParams.AddIgnoredActor(owner);
	// Perform the line trace
	GetWorld()->LineTraceSingleByChannel(Hit, traceStart, traceEnd,	ECollisionChannel::ECC_Visibility, CollisionParams);

	if (Hit.PhysMaterial != NULL) {
		switch (Hit.PhysMaterial->SurfaceType.GetValue()) {
		case ESurfaceTypes::GrassDirt:
			if (FootstepCues.Num()) {
				UGameplayStatics::PlaySoundAtLocation(GetWorld(), FootstepCues[ESurfaceTypes::GrassDirt - 1],
					                                                                                                            owner->GetActorLocation());

				ARPGCharacter* player = Cast<ARPGCharacter>(owner);
				// Activate the effect
				if (player)
					player->ActivateFootstepLeafPoof();
			}    // if
			break;
		case ESurfaceTypes::RockCliff:
			if (FootstepCues.Num())
				UGameplayStatics::PlaySoundAtLocation(GetWorld(),
					              FootstepCues[ESurfaceTypes::RockCliff - 1], owner->GetActorLocation());
			break;
		}
	}
}
