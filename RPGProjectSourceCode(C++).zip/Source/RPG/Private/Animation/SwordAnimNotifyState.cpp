/**********************************************************************************
Copyright � 2022 Dr. Chihming Chiu - All Right Reserved

The source code contained within this file is for the book,
UNREAL ENGINE 5 RPG DEVELOPMENT with C++ and Blueprint,
and is intended for educational purposes only.

Feel free to use this code provided you include the above copyright notice.
The code is provided "AS IS", without warranty of any kind, express or implied.
***********************************************************************************/
#include "Animation/SwordAnimNotifyState.h"
#include "Characters/WarriorCharacter.h"

void USwordAnimNotifyState::NotifyBegin(USkeletalMeshComponent* MeshComp,
	UAnimSequenceBase* Animation, float TotalDuration)
{
	AWarriorCharacter* warrior = Cast<AWarriorCharacter>(MeshComp->GetOwner());

	if (warrior)
	{
		warrior->ActivateSwordTrail(true);
	}
}

void USwordAnimNotifyState::NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
	AWarriorCharacter* warrior = Cast<AWarriorCharacter>(MeshComp->GetOwner());

	if (warrior)
	{
		warrior->ActivateSwordTrail(false);

		if (warrior->NextComboType != EComboTypes::Empty) {
			FText sectionName;
			UAnimMontage* montage = Cast<UAnimMontage>(Animation);
			const UEnum* EnumPtr = FindObject<UEnum>(ANY_PACKAGE,	TEXT("EComboSections"), true);

			switch (warrior->NextComboType) {
			case EComboTypes::LightMelee:
				if (EnumPtr)
					sectionName =
					EnumPtr->GetDisplayNameTextByValue(NextLightComboSection);
				if (montage) {
					warrior->PlayComboMontage(FName(sectionName.ToString()), montage);
				}
				break;
			case EComboTypes::HeavyMelee:
				if (EnumPtr)
					sectionName =
					EnumPtr->GetDisplayNameTextByValue(NextHeavyComboSection);

				if (montage) {
					warrior->PlayComboMontage(FName(sectionName.ToString()),
						montage);
				}
				break;
			}

			warrior->NextComboType = EComboTypes::Empty;
		}
		else {
			warrior->IsAttacking = false;
		}
	}
}
