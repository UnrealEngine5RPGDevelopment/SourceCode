/**********************************************************************************
Copyright � 2022 Dr. Chihming Chiu - All Right Reserved

The source code contained within this file is for the book,
UNREAL ENGINE 5 RPG DEVELOPMENT with C++ and Blueprint,
and is intended for educational purposes only.

Feel free to use this code provided you include the above copyright notice.
The code is provided "AS IS", without warranty of any kind, express or implied.
***********************************************************************************/
#include "Stats/CharacterStats.h"

UCharacterStats::UCharacterStats()
{
}

void UCharacterStats::SetStatValue(FString name, int value)
{
	BaseStats.Emplace(name, value);
}

void UCharacterStats::AddModifier(UStatsModifier* modifier)
{
	Modifiers.Add(modifier);
}

void UCharacterStats::RemoveModifier(UStatsModifier* modifier)
{
	Modifiers.Remove(modifier);
}

int UCharacterStats::GetStatValue(FString name)
{
	if (!BaseStats.IsEmpty() && BaseStats.Contains(name)) {
		int total = BaseStats[name];
		float multiplier = 0.0f;

		for (UStatsModifier* modifier : Modifiers)
		{
			if (modifier->Type == EModifierTypes::Add)
				total += modifier->ModifierValues[name];
			else
				multiplier += modifier->ModifierValues[name];
		}

		return FMath::RoundHalfFromZero(total + (total * multiplier));
	}
	else
		return 0;
}
