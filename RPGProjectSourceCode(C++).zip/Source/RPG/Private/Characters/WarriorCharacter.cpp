/**********************************************************************************
Copyright � 2022 Dr. Chihming Chiu - All Right Reserved

The source code contained within this file is for the book,
UNREAL ENGINE 5 RPG DEVELOPMENT with C++ and Blueprint,
and is intended for educational purposes only.

Feel free to use this code provided you include the above copyright notice.
The code is provided "AS IS", without warranty of any kind, express or implied.
***********************************************************************************/
#include "Characters/WarriorCharacter.h"
#include "Kismet/KismetMathLibrary.h"
#include "Inventory/Sword.h"

void AWarriorCharacter::PlayCastFireballMontage()
{
	if (IsValid(CastFireballMontage))
		PlayAnimMontage(CastFireballMontage);
}

void AWarriorCharacter::CastFireball()
{
	FVector FireballSocketLocation = GetMesh()->GetSocketLocation("FireballSocket");
	FActorSpawnParameters spawnParams;
	spawnParams.Owner = this;
	spawnParams.Instigator = GetInstigator();

	fireball = GetWorld()->SpawnActor<AFireball>(FireballClass, FireballSocketLocation, GetActorRotation(), spawnParams);

	if (fireball) {
		fireball->SetLifeSpan(FireballLifeSpan);
		fireball->SphereCollider->SetCollisionEnabled(ECollisionEnabled::QueryOnly);
	}
}

void AWarriorCharacter::ActivateSwordTrail(bool activate)
{
	if (RightHandWeapon) {
		ASword* sword = Cast<ASword>(RightHandWeapon->GetChildActor());

		if (sword)
			sword->ActivateSwordTrail(activate);
	}
}

AWarriorCharacter::AWarriorCharacter() : Super()
{
	RightHandWeapon =
		CreateDefaultSubobject<UChildActorComponent>(TEXT("RightHandWeapon"));

	RightHandWeapon->SetupAttachment(GetMesh(), "WeaponRestSocket");
	IsRightHandWeaponLoaded = false;
	CurrentComboType = EComboTypes::Empty;
}

void AWarriorCharacter::SetupPlayerInputComponent(class UInputComponent*	PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);

	PlayerInputComponent->BindAction("CastFireball", IE_Pressed, this, &AWarriorCharacter::PlayCastFireballMontage);

	PlayerInputComponent->BindAction("LightAttack", IE_Pressed, this, & AWarriorCharacter::LightAttack);
	PlayerInputComponent->BindAction("HeavyAttack", IE_Pressed, this,	&AWarriorCharacter::HeavyAttack);
}

void AWarriorCharacter::BeginPlay()
{
	Super::BeginPlay();

	const FTransform swordRestTransform(WeaponRestRotation);
	RightHandWeapon->SetRelativeTransform(swordRestTransform);
}

// Called every frame
void AWarriorCharacter::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
}

void AWarriorCharacter::LightAttack()
{
	FRotator targetRot;

	if (currentTarget) {
		targetRot = UKismetMathLibrary::FindLookAtRotation(GetActorLocation(), currentTarget->GetActorLocation());
		GetWorld()->GetFirstPlayerController()->SetControlRotation(targetRot);
	}

	IsAttacking = true;

	if (!IsRightHandWeaponLoaded) {
		CurrentComboType = EComboTypes::LightMelee;

		if (IsValid(DrawASwordMontage))
			PlayAnimMontage(DrawASwordMontage);
	}
	else	
	if (!GetMesh()->GetAnimInstance()->Montage_IsPlaying(GreatSwordSlashMontage)) {
		if (IsValid(GreatSwordSlashMontage)) {
			FText sectionName;
			const UEnum* EnumPtr = FindObject<UEnum>(ANY_PACKAGE, TEXT("EComboSections"), true);

			if (EnumPtr)
				sectionName = EnumPtr->GetDisplayNameTextByValue(DefaultLightSlashSection);

			PlayComboMontage(FName(sectionName.ToString()));
		}
	}
	else
		NextComboType = EComboTypes::LightMelee;
}

void AWarriorCharacter::HeavyAttack()
{
	FRotator targetRot;

	if (currentTarget) {
		targetRot = UKismetMathLibrary::FindLookAtRotation(GetActorLocation(),
			currentTarget->GetActorLocation());
		GetWorld()->GetFirstPlayerController()->SetControlRotation(targetRot);
	}

	IsAttacking = true;

	if (!IsRightHandWeaponLoaded) {
		CurrentComboType = EComboTypes::HeavyMelee;

		if (IsValid(DrawASwordMontage))
			PlayAnimMontage(DrawASwordMontage);
	}
	else	
	if (!GetMesh()->GetAnimInstance()->Montage_IsPlaying(GreatSwordSlashMontage)) {
		if (IsValid(GreatSwordSlashMontage)) {
			FText sectionName;
			const UEnum* EnumPtr =
				FindObject<UEnum>(ANY_PACKAGE, TEXT("EComboSections"), true);

			if (EnumPtr)
				sectionName =
				EnumPtr->GetDisplayNameTextByValue(DefaultHeavySlashSection);

			PlayComboMontage(FName(sectionName.ToString()));
		}
	}
	else
		NextComboType = EComboTypes::HeavyMelee;
}

void AWarriorCharacter::PlayComboMontage(FName section, UAnimMontage*	montage, float rate)
{
	if (IsValid(montage))
		PlayAnimMontage(montage, rate, section);
	else
		PlayAnimMontage(GreatSwordSlashMontage, rate, section);
}

void AWarriorCharacter::EquipAGreatSword()
{
	RightHandWeapon->AttachToComponent(GetMesh(), FAttachmentTransformRules::KeepRelativeTransform, "RightHandSwordSocket");
	const FTransform swordMountTransform(RightHandWeaponMountRotation);
	RightHandWeapon->SetRelativeTransform(swordMountTransform);

	IsRightHandWeaponLoaded = true;
}

void AWarriorCharacter::UnloadAGreatSword()
{
	if (IsRightHandWeaponLoaded) {

		// Load the great sword
		RightHandWeapon->AttachToComponent(GetMesh(),
			  FAttachmentTransformRules::KeepRelativeTransform, "WeaponRestSocket");
		const FTransform swordRestTransform(WeaponRestRotation);
		RightHandWeapon->SetRelativeTransform(swordRestTransform);

		IsRightHandWeaponLoaded = false;
	}
}

void AWarriorCharacter::DrawAGreatSwordNotify()
{
	if (!IsRightHandWeaponLoaded && CurrentComboType != EComboTypes::Empty) {
		EquipAGreatSword();

		if (CurrentComboType == EComboTypes::LightMelee)
			LightAttack();
		else if (CurrentComboType == EComboTypes::HeavyMelee)
			HeavyAttack();

		CurrentComboType == EComboTypes::Empty;
	}
}

void AWarriorCharacter::UnloadAGreatSwordNotify(bool PlayMontage)
{
	if (IsRightHandWeaponLoaded) {
		if (PlayMontage && IsValid(UnloadASwordMontage))
			PlayAnimMontage(UnloadASwordMontage);
		else
			UnloadAGreatSword();
	}
}


