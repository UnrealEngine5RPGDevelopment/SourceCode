/**********************************************************************************
Copyright � 2022 Dr. Chihming Chiu - All Right Reserved

The source code contained within this file is for the book,
UNREAL ENGINE 5 RPG DEVELOPMENT with C++ and Blueprint,
and is intended for educational purposes only.

Feel free to use this code provided you include the above copyright notice.
The code is provided "AS IS", without warranty of any kind, express or implied.
***********************************************************************************/
#include "Characters/HorseCharacter.h"
#include "UI/Interaction/InteractTextWidget.h"
#include "UI/Interaction/InteractableIconWidget.h"
#include "Kismet/KismetMathLibrary.h"

AHorseCharacter::AHorseCharacter()
{
	BoxCollider =	CreateDefaultSubobject<UBoxComponent>(TEXT("BoxComponent"));
	BoxCollider->SetupAttachment(RootComponent);
	DismountRight = CreateDefaultSubobject<USceneComponent>(TEXT("DismountRight"));
	DismountLeft =	CreateDefaultSubobject<USceneComponent>(TEXT("DismountLeft"));
	DismountLeft->SetupAttachment(RootComponent);
	DismountRight->SetupAttachment(RootComponent);
	InteractText =	CreateDefaultSubobject<UWidgetComponent>(TEXT("InteractText"));
	InteractText->SetupAttachment(RootComponent);
	InteractableIcon = CreateDefaultSubobject<UWidgetComponent>(TEXT("InteractableIcon"));
	InteractableIcon->SetupAttachment(RootComponent);
	BoxCollider->OnComponentBeginOverlap.AddDynamic(this, &AHorseCharacter::OnBoxBeginOverlap);
	BoxCollider->OnComponentEndOverlap.AddDynamic(this, &AHorseCharacter::OnBoxEndOverlap);
}

void AHorseCharacter::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);

	PlayerInputComponent->BindAction("Dismount", IE_Pressed, this, &AHorseCharacter::Dismount);
}

EInteractableType AHorseCharacter::GetInteractableType()
{
	return EInteractableType::Horse;
}

void  AHorseCharacter::Dismount()
{
	if (Rider) {
		ARPGCharacter* player = Cast<ARPGCharacter>(Rider);

		player->GetMesh()->DetachFromComponent(FDetachmentTransformRules::KeepWorldTransform);
		player->GetMesh()->AttachToComponent(player->GetRootComponent(), FAttachmentTransformRules::KeepWorldTransform);
		player->GetMesh()->SetRelativeTransform(player->OriginalTransform);
		player->SetActorRelativeLocation(DismountLeft->GetComponentLocation());

		player->IsRiding = false;
		AController* controller = GetController();
		controller->Possess(player);

		BoxCollider->SetCollisionEnabled(ECollisionEnabled::QueryOnly);
		player->SetActorEnableCollision(true);
		
		player->UpdateStaminaUI(player->Stats->GetStatValue("STA"), player->Stats->GetStatValue("MaxSTA"));
		player->RestartTimer();
	}
}

void AHorseCharacter::OnBoxBeginOverlap(UPrimitiveComponent*
	OverlappedComp, AActor* OtherActor, UPrimitiveComponent* OtherComp,
	int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult)
{
	FString componentName;
	OtherComp->GetName(componentName);

	if (componentName != "EnemyLockBox") {
		ARPGCharacter* player = Cast<ARPGCharacter>(OtherActor);

		if (player && player != this)
		{
			player->InteractableActor = this;
			ShowInteractText(true);
		}
	}
}

void AHorseCharacter::OnBoxEndOverlap(UPrimitiveComponent* OverlappedComp,
	AActor* OtherActor, UPrimitiveComponent* OtherComp,
	int32 OtherBodyIndex)
{
	ARPGCharacter* player = Cast<ARPGCharacter>(OtherActor);

	if (player)
	{
		FString componentName;
		OtherComp->GetName(componentName);

		if (componentName != "EnemyLockBox") {
			player->InteractableActor = NULL;
			ShowInteractText(false);
		}
	}
}

void AHorseCharacter::ShowInteractText(bool visible, FString text)
{
	if (InteractText) {
		UInteractTextWidget* interactText =
			Cast<UInteractTextWidget>(InteractText->GetUserWidgetObject());

		if (interactText && text != "") {
			interactText->InteractText->SetText(FText::FromString(text));
		}

		InteractText->SetVisibility(visible);
		// Hide Interactable icon
		InteractableIcon->SetVisibility(!visible);
	}
}

void AHorseCharacter::ShowInteractableIcon(bool visible, AActor* facingActor)
{
	if (InteractableIcon) {
		UInteractableIconWidget* interactableIconWidget =
			Cast<UInteractableIconWidget>(InteractableIcon->GetUserWidgetObject());
	
		if (interactableIconWidget) {
			if (visible) {
				InteractableIcon->SetVisibility(true);
				interactableIconWidget->SetVisibility(ESlateVisibility::Visible);

				interactableIconWidget->PlayMovingAnimation();

				if (facingActor) {
					FRotator rotation =
						UKismetMathLibrary::FindLookAtRotation(GetActorLocation(), facingActor->GetActorLocation());
					InteractableIcon->SetWorldRotation(rotation);
				}
			}
			else {    
				interactableIconWidget->SetVisibility(ESlateVisibility::Hidden);
			}
		}
	}
}
