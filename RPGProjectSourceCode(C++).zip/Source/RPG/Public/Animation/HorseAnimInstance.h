/**********************************************************************************
Copyright � 2022 Dr. Chihming Chiu - All Right Reserved

The source code contained within this file is for the book,
UNREAL ENGINE 5 RPG DEVELOPMENT with C++ and Blueprint,
and is intended for educational purposes only.

Feel free to use this code provided you include the above copyright notice.
The code is provided "AS IS", without warranty of any kind, express or implied.
***********************************************************************************/
#pragma once

#include "CoreMinimal.h"
#include "Animation/RPGAnimInstance.h"
#include "HorseAnimInstance.generated.h"

/**
 * 
 */
UCLASS()
class RPG_API UHorseAnimInstance : public URPGAnimInstance
{
	GENERATED_BODY()
public:

	UPROPERTY(EditDefaultsOnly, Category = "Sockets")
	FName SlopeTraceStartSocket;
	UPROPERTY(EditDefaultsOnly, Category = "Sockets")
	FName SlopeTraceEndSocket;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Offsets")
	float FrontLeftLegOffset;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Offsets")
	float FrontRightLegOffset;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Offsets")
	float RearLeftLegOffset;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Offsets")
	float RearRightLegOffset;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Offsets")
	float TraceStartZOffset;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Rotator")
	float Pitch;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Rotator")
	float PitchMin = -35;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Rotator")
	float PitchMax = 35;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Offsets")
	float FrontLegsOffsetMax = 50;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Offsets")
	float RearLegsOffsetMax = 50;

	UPROPERTY(EditAnywhere, Category = "Sockets")
	FName FrontLeftLegSocket;
	UPROPERTY(EditAnywhere, Category = "Sockets")
	FName FrontRightLegSocket;
	UPROPERTY(EditAnywhere, Category = "Sockets")
	FName RearLeftLegSocket;
	UPROPERTY(EditAnywhere, Category = "Sockets")
	FName RearRightLegSocket;
	UPROPERTY(EditDefaultsOnly, Category = "Sockets")
	FName FrontLegsSocket;
	UPROPERTY(EditDefaultsOnly, Category = "Sockets")
	FName RearLegsSocket;

	bool TraceGround(FName socket, FVector& impactPoint,
	float startZOffset = 0);
	float CalculatePitch(float min, float max);

	virtual void NativeUpdateAnimation(float DeltaSeconds) override;

protected:
	virtual void NativeBeginPlay() override;
private:
	USkeletalMeshComponent* mesh;
};
