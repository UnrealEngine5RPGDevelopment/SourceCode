/**********************************************************************************
Copyright � 2022 Dr. Chihming Chiu - All Right Reserved

The source code contained within this file is for the book,
UNREAL ENGINE 5 RPG DEVELOPMENT with C++ and Blueprint,
and is intended for educational purposes only.

Feel free to use this code provided you include the above copyright notice.
The code is provided "AS IS", without warranty of any kind, express or implied.
***********************************************************************************/
#pragma once

#include "CoreMinimal.h"
#include "Animation/AnimNotifies/AnimNotifyState.h"
#include "SwordAnimNotifyState.generated.h"

/**
 * 
 */
UENUM()
enum EComboSections
{
	None                     UMETA(DisplayName = "None"),
	HorizontalSlash     UMETA(DisplayName = "HorizontalSlash"),
	DiagontalSlash      UMETA(DisplayName = "DiagontalSlash"),
	JumpAttack          UMETA(DisplayName = "JumpAttack"),
	SlideAttack           UMETA(DisplayName = "SlideAttack"),
	RotateSlash          UMETA(DisplayName = "RotateSlash")
};

UCLASS()
class RPG_API USwordAnimNotifyState : public UAnimNotifyState
{
	GENERATED_BODY()
public:
	virtual void NotifyBegin(USkeletalMeshComponent*	MeshComp, UAnimSequenceBase* Animation, float TotalDuration) override;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Combo")
	TEnumAsByte<EComboSections> NextLightComboSection;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Combo")
	TEnumAsByte<EComboSections> NextHeavyComboSection;

	virtual void NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animatioin) override;

};
