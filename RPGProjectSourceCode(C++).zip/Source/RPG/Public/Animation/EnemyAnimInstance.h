/**********************************************************************************
Copyright � 2022 Dr. Chihming Chiu - All Right Reserved

The source code contained within this file is for the book,
UNREAL ENGINE 5 RPG DEVELOPMENT with C++ and Blueprint,
and is intended for educational purposes only.

Feel free to use this code provided you include the above copyright notice.
The code is provided "AS IS", without warranty of any kind, express or implied.
***********************************************************************************/
#pragma once

#include "CoreMinimal.h"
#include "Animation/RPGAnimInstance.h"
#include "EnemyAnimInstance.generated.h"

/**
 * 
 */
UCLASS()
class RPG_API UEnemyAnimInstance : public URPGAnimInstance
{
	GENERATED_BODY()
public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "States")
	bool IsResting = false;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "States")
	bool IsMoving = false;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Direction")
	float Direction;

	virtual void NativeUpdateAnimation(float DeltaSeconds) override;

};
