/**********************************************************************************
Copyright � 2022 Dr. Chihming Chiu - All Right Reserved

The source code contained within this file is for the book,
UNREAL ENGINE 5 RPG DEVELOPMENT with C++ and Blueprint,
and is intended for educational purposes only.

Feel free to use this code provided you include the above copyright notice.
The code is provided "AS IS", without warranty of any kind, express or implied.
***********************************************************************************/
#pragma once

#include "CoreMinimal.h"
#include "NPC/NPC.h"
#include "Components/WidgetComponent.h"
#include "../Interfaces/Health.h"
#include "../Stats/CharacterStats.h"
#include "../Interfaces/Lock.h"
#include "NiagaraComponent.h"
#include "Components/TimelineComponent.h"
#include "Materials/MaterialParameterCollectionInstance.h"
#include "Enemy.generated.h"

/**
 * 
 */
UCLASS()
class RPG_API AEnemy : public ANPC, public IHealth, public ILock
{
	GENERATED_BODY()
public:
	AEnemy();

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Respawn")
	TSubclassOf<AEnemy> EnemyClass;
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Respawn")
	bool Respawnable = true;
	FVector CalculateRespawnLocation();
	virtual void Respawn();

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Niagara")
	UNiagaraComponent* DisintegrationFX;
	UFUNCTION()
	virtual void TimelineProgress(float value);
	void ActivateDisintegration(bool activate,
	FVector location = FVector(0, 0, 0));

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Widgets")
	UWidgetComponent* DamageText;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Widgets")
	UWidgetComponent* LockWidget;
	void ShowLocked(bool visible) override;

	UPROPERTY(Instanced, EditAnywhere, Category = "Stats")
	UCharacterStats* Stats;
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Widgets")
	UWidgetComponent* HealthBar;
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Montages")
	TArray<UAnimMontage*> DeathMontages;
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Montages")
	TArray<UAnimMontage*> GetHitMontages;
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Montages")
	TArray<UAnimMontage*> AttackMontages;

	virtual void ApplyDamage(int damageValue, AActor* causer) override;
	virtual bool IsDead() override;
	virtual void PlayDeathMontage();
	virtual void PlayGetHitMontage();
	void ResizeHealthBar(int hp);

protected:
	virtual void BeginPlay() override;
	virtual void Tick(float DeltaTime) override;

	FTimeline CurveFTimeline;
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Timeline")
	UCurveFloat* CurveFloat;
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Timeline")
	float EndDisintegrationRadius;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category =	"MaterialParameterCollection")
	UMaterialParameterCollection* MaterialParameterCollectionAsset;
	UMaterialParameterCollectionInstance* MPCInst;
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category =	"MaterialParameterCollection")
	FString RadiusParameterName;
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category =	"MaterialParameterCollection")
	FString HardnessParameterName;
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category =	"MaterialParameterCollection")
	FString LocationParameterName;

private:
	bool isDead = false;

};
