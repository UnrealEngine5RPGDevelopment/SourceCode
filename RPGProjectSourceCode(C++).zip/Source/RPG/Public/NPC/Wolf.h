/**********************************************************************************
Copyright � 2022 Dr. Chihming Chiu - All Right Reserved

The source code contained within this file is for the book,
UNREAL ENGINE 5 RPG DEVELOPMENT with C++ and Blueprint,
and is intended for educational purposes only.

Feel free to use this code provided you include the above copyright notice.
The code is provided "AS IS", without warranty of any kind, express or implied.
***********************************************************************************/
#pragma once

#include "CoreMinimal.h"
#include "NPC/Enemy.h"
#include "Wolf.generated.h"

/**
 * 
 */
UCLASS()
class RPG_API AWolf : public AEnemy
{
	GENERATED_BODY()

public:
	AWolf();

	void Respawn() override;
};
