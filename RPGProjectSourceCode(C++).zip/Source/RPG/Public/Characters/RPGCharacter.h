/**********************************************************************************
Copyright � 2022 Dr. Chihming Chiu - All Right Reserved

The source code contained within this file is for the book,
UNREAL ENGINE 5 RPG DEVELOPMENT with C++ and Blueprint,
and is intended for educational purposes only.

Feel free to use this code provided you include the above copyright notice.
The code is provided "AS IS", without warranty of any kind, express or implied.
***********************************************************************************/
#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "Camera/CameraComponent.h"
#include "GameFramework/SpringArmComponent.h"
#include "../Stats/CharacterStats.h"
#include "UI/RPGHUD.h"
#include "Components/BoxComponent.h"
#include "RPGCharacter.generated.h"

UCLASS()
class RPG_API ARPGCharacter : public ACharacter
{
	GENERATED_BODY()

public:
	// Sets default values for this character's properties
	ARPGCharacter();
	
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Niagara")
	class UNiagaraComponent* FootstepLeafPoof;

	void ActivateFootstepLeafPoof();

	UPROPERTY(VisibleAnywhere, Category = "Riding")
	bool IsRiding = false;
	UPROPERTY(VisibleAnywhere, Category = "Riding")
	AActor* InteractableActor;
	UPROPERTY(VisibleAnywhere, Category = "Riding")
	FTransform OriginalTransform;
	UFUNCTION()
	void Interact();

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "EnemyLock")
	UBoxComponent* EnemyLockBox;
	UFUNCTION()
	void OnLockBoxBeginOverlap(UPrimitiveComponent* OverlappedComp, AActor*
			OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool
			bFromSweep, const FHitResult& SweepResult);
	UFUNCTION()
	void OnLockBoxEndOverlap(UPrimitiveComponent* OverlappedComp, AActor*
			OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex);

	AActor* currentTarget;

	UPROPERTY(EditDefaultsOnly, Category = "Sprint")
	bool IsSprinting = false;
	UPROPERTY(EditDefaultsOnly, Category = "Constraints")
	float SprintCost = 10;
	UPROPERTY(EditDefaultsOnly, Category = "Stamina")
	float StaminaRecoveryRate = 0.2f;
	ARPGHUD* RPGHUD;
	FTimerHandle SprintDrainTimerHandle;
	FTimerHandle RegenerateStaminaTimerHandle;

	UFUNCTION()
	void SprintDrain();
	UFUNCTION()
	void RegenerateStamina();
	void ClearTimer();
	void RestartTimer();
	void UpdateStaminaUI(int stamina, int maxStamina = 0);

	UPROPERTY(Instanced, EditAnywhere, Category = "Stats")
	UCharacterStats* Stats;

	UPROPERTY(EditDefaultsOnly, Category = "Jump")
	int MaxJumpCount = 2;
	int jumpCount = 0;
	void Jump();
	void Landed(const FHitResult& Hit) override;

	UPROPERTY(EditDefaultsOnly, Category = "Speed")
	float WalkSpeed = 300.0f;
	UPROPERTY(EditDefaultsOnly, Category = "Speed")
	float RunSpeed = 600.0f;

	void MoveForward(float axis);
	void MoveBackward(float axis);
	void MoveLeft(float axis);
	void MoveRight(float axis);
	void Walk();
	void Sprint();

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "MouseLook")
	float MaxMousePitch = 80.0f;
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "MouseZoom")
	float MinTargetArmLength = 100.0f;
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "MouseZoom")
	float MaxTargetArmLength = 800.0f;
	void MouseZoom(float val);
	virtual void AddControllerYawInput(float Val) override;
	virtual void AddControllerPitchInput(float Val) override;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Camera)
	UCameraComponent* FollowCamera;
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Camera)
	USpringArmComponent* CameraBoom;
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Direction")
	FVector2D Direction;

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;
public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;

	// Called to bind functionality to input
	virtual void SetupPlayerInputComponent(class UInputComponent* PlayerInputComponent) override;

};
