/**********************************************************************************
Copyright � 2022 Dr. Chihming Chiu - All Right Reserved

The source code contained within this file is for the book,
UNREAL ENGINE 5 RPG DEVELOPMENT with C++ and Blueprint,
and is intended for educational purposes only.

Feel free to use this code provided you include the above copyright notice.
The code is provided "AS IS", without warranty of any kind, express or implied.
***********************************************************************************/
#pragma once

#include "CoreMinimal.h"
#include "Characters/RPGCharacter.h"
#include "../Animation/SwordAnimNotifyState.h"
#include "../Spells/Fireball.h"
#include "WarriorCharacter.generated.h"

/**
 * 
 */

UENUM()
enum EComboTypes
{
	Empty               UMETA(DisplayName = "Empty"),
	LightMelee          UMETA(DisplayName = "LightMelee"),
	HeavyMelee          UMETA(DisplayName = "HeavyMelee")
};

UCLASS()
class RPG_API AWarriorCharacter : public ARPGCharacter
{
	GENERATED_BODY()
public:
	AWarriorCharacter();

	void PlayCastFireballMontage();
	void CastFireball();

	void ActivateSwordTrail(bool activate);

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Weapon")
	bool IsRightHandWeaponLoaded;
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Weapon")
	UChildActorComponent* RightHandWeapon;
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Weapon")
	FRotator WeaponRestRotation;
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Weapon")
	FRotator RightHandWeaponMountRotation;
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Montages")
	UAnimMontage* DrawASwordMontage;
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Montages")
	UAnimMontage* UnloadASwordMontage;
	TEnumAsByte<EComboTypes> CurrentComboType;

	void EquipAGreatSword();
	void UnloadAGreatSword();
	void DrawAGreatSwordNotify();
	void UnloadAGreatSwordNotify(bool PlayMontage);

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Montages")
	UAnimMontage* GreatSwordSlashMontage;
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Combo")
	TEnumAsByte<EComboSections> DefaultLightSlashSection;
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Combo")
	TEnumAsByte<EComboSections> DefaultHeavySlashSection;
	TEnumAsByte<EComboTypes> NextComboType;
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Combo")
	bool IsAttacking = false;

	virtual void PlayComboMontage(FName section, UAnimMontage* montage = 0, float rate = 1.0f);
	void LightAttack();
	void HeavyAttack();
	
	virtual void SetupPlayerInputComponent(class UInputComponent*	PlayerInputComponent) override;
	virtual void BeginPlay() override;
	// Called every frame
	virtual void Tick(float DeltaTime) override;

protected:
	AFireball* fireball;
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Montages")
	UAnimMontage* CastFireballMontage;
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Fireball")
	TSubclassOf<AFireball> FireballClass;
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Fireball")
	float FireballLifeSpan;
};
