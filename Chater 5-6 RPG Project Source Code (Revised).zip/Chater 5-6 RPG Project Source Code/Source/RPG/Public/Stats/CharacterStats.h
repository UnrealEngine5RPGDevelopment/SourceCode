/**********************************************************************************
Copyright � 2022 Dr. Chihming Chiu - All Right Reserved

The source code contained within this file is for the book,
UNREAL ENGINE 5 RPG DEVELOPMENT with C++ and Blueprint,
and is intended for educational purposes only.

Feel free to use this code provided you include the above copyright notice.
The code is provided "AS IS", without warranty of any kind, express or implied.
***********************************************************************************/
#pragma once

#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"
#include "StatsModifier.h"
#include "CharacterStats.generated.h"

/**
 * 
 */
UCLASS(Blueprintable, DefaultToInstanced, EditInlineNew)
class RPG_API UCharacterStats : public UObject
{
	GENERATED_BODY()
public:
	UCharacterStats();

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "BaseStats")
	TMap<FString, int> BaseStats;
	void SetStatValue(FString name, int value);

	UPROPERTY(EditDefaultsOnly, Category = "Modifiers")
	TArray<UStatsModifier*> Modifiers;
	void AddModifier(UStatsModifier* modifier);
	void RemoveModifier(UStatsModifier* modifier);
	int GetStatValue(FString name);

};
