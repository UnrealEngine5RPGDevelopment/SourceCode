/**********************************************************************************
Copyright � 2022 Dr. Chihming Chiu - All Right Reserved

The source code contained within this file is for the book,
UNREAL ENGINE 5 RPG DEVELOPMENT with C++ and Blueprint,
and is intended for educational purposes only.

Feel free to use this code provided you include the above copyright notice.
The code is provided "AS IS", without warranty of any kind, express or implied.
***********************************************************************************/
#pragma once

#include "CoreMinimal.h"
#include "Inventory/Weapon.h"
#include "NiagaraComponent.h"
#include "Sword.generated.h"

/**
 * 
 */
UCLASS()
class RPG_API ASword : public AWeapon
{
	GENERATED_BODY()
public:
	ASword();

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Niagara")
	UNiagaraComponent* SwordTrail;

	void ActivateSwordTrail(bool activate);

	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = Trace)
	float TraceRadius = 30.0f;
	UFUNCTION()
	void OnSwordBeginOverlap(UPrimitiveComponent* OverlappedComp, AActor*
			OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex,
			bool bFromSweep, const FHitResult& SweepResult);

};
