/**********************************************************************************
Copyright � 2022 Dr. Chihming Chiu - All Right Reserved

The source code contained within this file is for the book,
UNREAL ENGINE 5 RPG DEVELOPMENT with C++ and Blueprint,
and is intended for educational purposes only.

Feel free to use this code provided you include the above copyright notice.
The code is provided "AS IS", without warranty of any kind, express or implied.
***********************************************************************************/
#pragma once

#include "CoreMinimal.h"
#include "Characters/RPGCharacter.h"
#include "Components/BoxComponent.h"
#include "Components/SceneComponent.h"
#include "../Interfaces/Interactable.h"
#include "Components/WidgetComponent.h"
#include "HorseCharacter.generated.h"

/**
 * 
 */
UCLASS()
class RPG_API AHorseCharacter : public ARPGCharacter, public IInteractable
{
	GENERATED_BODY()
public:
	AHorseCharacter();

	UPROPERTY(VisibleAnywhere, Category = "Collider")
	UBoxComponent* BoxCollider;
	UPROPERTY(VisibleAnywhere, Category = "Dismount")
	USceneComponent* DismountRight;
	UPROPERTY(VisibleAnywhere, Category = "Dismount")
	USceneComponent* DismountLeft;
	UPROPERTY(VisibleAnywhere, Category = "Widget")
	UWidgetComponent* InteractText;
	UPROPERTY(VisibleAnywhere, Category = "Widget")
	UWidgetComponent* InteractableIcon;
	UPROPERTY(VisibleAnywhere, Category = "Interactable")
	TEnumAsByte<EInteractableType> InteractableType;
	UPROPERTY(VisibleAnywhere, Category = "Rider")
	AActor* Rider;

	UFUNCTION()
	void Dismount();
	UFUNCTION()
	void OnBoxBeginOverlap(UPrimitiveComponent* OverlappedComp, AActor*
			OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex,
			bool bFromSweep, const FHitResult& SweepResult);
	UFUNCTION()
	void OnBoxEndOverlap(UPrimitiveComponent* OverlappedComp, AActor*
			OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex);
	virtual EInteractableType GetInteractableType() override;
	virtual void ShowInteractText(bool visible, FString text = "") override;
	virtual void ShowInteractableIcon(bool visible, AActor*	facingActor = NULL) override;
	virtual void SetupPlayerInputComponent(class UInputComponent*	PlayerInputComponent) override;

};
