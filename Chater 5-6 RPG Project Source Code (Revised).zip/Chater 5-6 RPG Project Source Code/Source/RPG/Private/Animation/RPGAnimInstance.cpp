/**********************************************************************************
Copyright � 2022 Dr. Chihming Chiu - All Right Reserved

The source code contained within this file is for the book,
UNREAL ENGINE 5 RPG DEVELOPMENT with C++ and Blueprint,
and is intended for educational purposes only.

Feel free to use this code provided you include the above copyright notice.
The code is provided "AS IS", without warranty of any kind, express or implied.
***********************************************************************************/
#include "Animation/RPGAnimInstance.h"
#include "Characters/RPGCharacter.h"
#include "GameFramework/PawnMovementComponent.h"

void URPGAnimInstance::NativeUpdateAnimation(float DeltaSeconds)
{
	Super::NativeUpdateAnimation(DeltaSeconds);

	ARPGCharacter* owningActor = Cast<ARPGCharacter>(GetOwningActor());

	if (IsValid(owningActor))
	{
		float Speed = owningActor->GetVelocity().Size();

		ForwardSpeed = owningActor->Direction.Y * Speed;
		SideSpeed = owningActor->Direction.X * Speed;
		IsFalling = owningActor->GetMovementComponent()->IsFalling();
		IsRiding = owningActor->IsRiding;
	}
}
