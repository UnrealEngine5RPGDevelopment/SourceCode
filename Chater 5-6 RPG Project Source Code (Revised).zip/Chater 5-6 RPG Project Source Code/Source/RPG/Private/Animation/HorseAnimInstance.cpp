/**********************************************************************************
Copyright � 2022 Dr. Chihming Chiu - All Right Reserved

The source code contained within this file is for the book,
UNREAL ENGINE 5 RPG DEVELOPMENT with C++ and Blueprint,
and is intended for educational purposes only.

Feel free to use this code provided you include the above copyright notice.
The code is provided "AS IS", without warranty of any kind, express or implied.
***********************************************************************************/
#include "Animation/HorseAnimInstance.h"
#include "Characters/RPGCharacter.h"
#include "Kismet/KismetSystemLibrary.h"

void UHorseAnimInstance::NativeBeginPlay()
{
	AActor* owner = GetOwningActor();

	if (owner) {
		ARPGCharacter* horse = Cast<ARPGCharacter>(owner);

		if (horse) {
			mesh = horse->GetMesh();
			// Initialize the Pitch
			Pitch = CalculatePitch(PitchMin, PitchMax);
		}
	}
}

bool UHorseAnimInstance::TraceGround(FName socket, FVector& impactPoint,	float startZOffset)
{
	if (mesh) {
		FVector socketLocation = mesh->GetSocketLocation(socket);
		FVector traceStart = socketLocation + FVector(0, 0, startZOffset);
		FVector traceEnd = socketLocation - FVector(0, 0, 200);
		FHitResult hitResult(ForceInit);

		FCollisionQueryParams CollisionParams;
		CollisionParams.AddIgnoredActor(GetOwningActor());
		TArray<AActor*> actorsToIgnore;
		actorsToIgnore.Add(GetOwningActor());

		bool isHit = UKismetSystemLibrary::LineTraceSingle(GetWorld(), traceStart, traceEnd, UEngineTypes::ConvertToTraceType(
				ECC_Visibility), false, actorsToIgnore, EDrawDebugTrace::ForOneFrame, hitResult, true,
			                                                                                      FLinearColor::Red, FLinearColor::Blue, 1.0f);

		if (isHit) {
			impactPoint = hitResult.ImpactPoint;
			return true;
		}
		else
			return false;
	}

	return false;
}

float UHorseAnimInstance::CalculatePitch(float min, float max)
{
	FVector startLocation, endLocation;
	bool isHitStart = TraceGround(SlopeTraceStartSocket, startLocation, 	-70);
	bool isHitEnd = TraceGround(SlopeTraceEndSocket, endLocation, -50);

	if (isHitStart && isHitEnd) {
		FVector xAxis = startLocation - endLocation;
		FRotator rotator = FRotationMatrix::MakeFromX(xAxis).Rotator();

		if (rotator.Pitch > max)
			return max;
		else if (rotator.Pitch < min)
			return min;
		else
			return rotator.Pitch;
	}

	return 0;
}

//================================================
void UHorseAnimInstance::NativeUpdateAnimation(float DeltaSeconds)
{
	Super::NativeUpdateAnimation(DeltaSeconds);

	if (GetWorld()->WorldType != EWorldType::Editor) {
		if ((ForwardSpeed != 0 || SideSpeed != 0) && mesh) {
			// Front legs IK trace
			FVector impactPoint;
			TraceGround(FrontLeftLegSocket, impactPoint, 35);
			FVector frontSocketLocation = mesh->GetSocketLocation(FrontLegsSocket);
			FrontLeftLegOffset = impactPoint.Z - frontSocketLocation.Z;
			TraceGround(FrontRightLegSocket, impactPoint, 35);
			FrontRightLegOffset = impactPoint.Z - frontSocketLocation.Z;

			if (FrontLeftLegOffset > FrontLegsOffsetMax)
				FrontLeftLegOffset = FrontLegsOffsetMax;
			if (FrontRightLegOffset > FrontLegsOffsetMax)
				FrontRightLegOffset = FrontLegsOffsetMax;

			if (FrontLeftLegOffset > FrontLegsOffsetMax)
				FrontLeftLegOffset = FrontLegsOffsetMax;
			if (FrontRightLegOffset > FrontLegsOffsetMax)
				FrontRightLegOffset = FrontLegsOffsetMax;
			// Rear legs IK trace
			TraceGround(RearLeftLegSocket, impactPoint, 20);
			FVector rearSocketLocation = mesh->GetSocketLocation(RearLegsSocket);
			RearLeftLegOffset = impactPoint.Z - rearSocketLocation.Z;
			TraceGround(RearRightLegSocket, impactPoint, 20);
			RearRightLegOffset = impactPoint.Z - rearSocketLocation.Z;

			if (RearLeftLegOffset > RearLegsOffsetMax)
				RearLeftLegOffset = RearLegsOffsetMax;
			if (RearRightLegOffset > RearLegsOffsetMax)
				RearRightLegOffset = RearLegsOffsetMax;

			Pitch = 0;
			Pitch = CalculatePitch(PitchMin, PitchMax);
		}
	}
}

