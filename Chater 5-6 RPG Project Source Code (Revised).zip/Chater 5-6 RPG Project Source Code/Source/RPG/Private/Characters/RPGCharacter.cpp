/**********************************************************************************
Copyright � 2022 Dr. Chihming Chiu - All Right Reserved

The source code contained within this file is for the book,
UNREAL ENGINE 5 RPG DEVELOPMENT with C++ and Blueprint,
and is intended for educational purposes only.

Feel free to use this code provided you include the above copyright notice.
The code is provided "AS IS", without warranty of any kind, express or implied.
***********************************************************************************/
#include "Characters/RPGCharacter.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "UI/StaminaBarWidget.h"
#include "Interfaces/Lock.h"
#include "Interfaces/Health.h"
#include "Interfaces/Interactable.h"
#include "Characters/HorseCharacter.h"
#include "NiagaraComponent.h"

void ARPGCharacter::Interact()
{
	if (InteractableActor) {
		IInteractable* interactable = Cast<IInteractable>(InteractableActor);

		if (interactable->GetInteractableType() == EInteractableType::Horse) {
			interactable->ShowInteractText(false);
			interactable->ShowInteractableIcon(false);

			FName mountSocket = TEXT("MountSocket");
			OriginalTransform = GetMesh()->GetRelativeTransform();

			AHorseCharacter* horse = Cast<AHorseCharacter>(InteractableActor);

			if (horse) {
				GetMesh()->AttachToComponent(horse->GetMesh(), FAttachmentTransformRules::KeepRelativeTransform, mountSocket);
				IsRiding = true;
				horse->Rider = this;

				AController* controller = GetController();
				controller->Possess(horse);

				horse->BoxCollider->SetCollisionEnabled(ECollisionEnabled::NoCollision);
				SetActorEnableCollision(false);
			
				ClearTimer();

				Stats->SetStatValue("STA", Stats->GetStatValue("MaxSTA"));
				UpdateStaminaUI(horse->Stats->GetStatValue("STA"), horse->Stats->GetStatValue("MaxSTA"));
			}
		}
	}
}

ARPGCharacter::ARPGCharacter()
{
 	// Set this character to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	CameraBoom = CreateDefaultSubobject<USpringArmComponent>(TEXT("CameraBoom"));
	FollowCamera =	CreateDefaultSubobject<UCameraComponent>(TEXT("FollowCamera"));
	CameraBoom->SetupAttachment(RootComponent);
	FollowCamera->SetupAttachment(CameraBoom,	USpringArmComponent::SocketName);

	CameraBoom->TargetArmLength = 300.0f;
	EnemyLockBox = CreateDefaultSubobject<UBoxComponent>(TEXT("EnemyLockBox"));
	EnemyLockBox->SetupAttachment(CameraBoom);

	EnemyLockBox->OnComponentBeginOverlap.AddDynamic(this,	&ARPGCharacter::OnLockBoxBeginOverlap);
	EnemyLockBox->OnComponentEndOverlap.AddDynamic(this,	&ARPGCharacter::OnLockBoxEndOverlap);

	FootstepLeafPoof = CreateDefaultSubobject<UNiagaraComponent>(TEXT("FootstepLeafPoof"));
	FootstepLeafPoof->SetupAttachment(RootComponent);
	
}

void ARPGCharacter::ActivateFootstepLeafPoof()
{
	if (FootstepLeafPoof)
		FootstepLeafPoof->Activate(true);
}

// Called when the game starts or when spawned
void ARPGCharacter::BeginPlay()
{
	Super::BeginPlay();
	
	GetCharacterMovement()->MaxWalkSpeed = WalkSpeed;
	
	GetWorld()->GetTimerManager().SetTimer(RegenerateStaminaTimerHandle, this, &ARPGCharacter::RegenerateStamina, 0.5f, true);
	RPGHUD = Cast<ARPGHUD>(GetWorld()->GetFirstPlayerController()->GetHUD());
}

// Called every frame
void ARPGCharacter::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

// Called to bind functionality to input
void ARPGCharacter::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);

	PlayerInputComponent->BindAction("Interact", IE_Pressed, this, &ARPGCharacter::Interact);
	PlayerInputComponent->BindAction("Jump", IE_Pressed, this, &ARPGCharacter::Jump);

	PlayerInputComponent->BindAxis("Turn", this,	&ARPGCharacter::AddControllerYawInput);
	PlayerInputComponent->BindAxis("LookUp", this, &ARPGCharacter::AddControllerPitchInput);
	PlayerInputComponent->BindAxis("MouseZoom", this, 	&ARPGCharacter::MouseZoom);

	PlayerInputComponent->BindAxis("MoveForward", this, &ARPGCharacter::MoveForward);
	PlayerInputComponent->BindAxis("MoveBackward", this, 	&ARPGCharacter::MoveBackward);
	PlayerInputComponent->BindAxis("MoveLeft", this,	&ARPGCharacter::MoveLeft);
	PlayerInputComponent->BindAxis("MoveRight", this,	&ARPGCharacter::MoveRight);
	PlayerInputComponent->BindAction("Sprint", IE_Pressed, this,	 &ARPGCharacter::Sprint);
	PlayerInputComponent->BindAction("Walk", IE_Released, this,	 &ARPGCharacter::Walk);
}

void ARPGCharacter::AddControllerYawInput(float Val)
{
	if (Val != 0) {
		CameraBoom->AddRelativeRotation(FRotator(0, Val, 0));
	}
}

void ARPGCharacter::AddControllerPitchInput(float Val)
{
	Super::AddControllerPitchInput(Val);
	float pitch = CameraBoom->GetRelativeRotation().Pitch + Val;
	// Clamp the Pitch to an appropriate value 
	pitch = FMath::Clamp(pitch, -MaxMousePitch, MaxMousePitch);
	FRotator rotation = FRotator(pitch, CameraBoom->GetRelativeRotation().Yaw, 0);
	CameraBoom->SetRelativeRotation(rotation);
}

void ARPGCharacter::MouseZoom(float val)
{
	float armLength = CameraBoom->TargetArmLength + val;
	CameraBoom->TargetArmLength = FMath::Clamp(armLength, MinTargetArmLength, MaxTargetArmLength);
}

void ARPGCharacter::MoveForward(float axis)
{
	if (axis > 0) {
		float controllerYaw = CameraBoom->GetRelativeRotation().Yaw;
		GetWorld()->GetFirstPlayerController()->SetControlRotation(FRotator(0, controllerYaw, 0));
		AddMovementInput(GetActorForwardVector(), axis);

		Direction.X = 0;
		Direction.Y = axis;
	} 
}

void ARPGCharacter::MoveBackward(float axis)
{
	if (axis < 0) {
		float controllerYaw = CameraBoom->GetRelativeRotation().Yaw + 180.0f;
		GetWorld()->GetFirstPlayerController()->SetControlRotation(FRotator(0,	controllerYaw, 0));
		AddMovementInput(GetActorForwardVector(), -axis);

		Direction.X = 0;
		Direction.Y = axis;
	}
}

void ARPGCharacter::MoveLeft(float axis)
{
	if (axis < 0) {
		float controllerYaw = CameraBoom->GetRelativeRotation().Yaw - 90.0f;
		GetWorld()->GetFirstPlayerController()->SetControlRotation(FRotator(0, controllerYaw, 0));

		AddMovementInput(GetActorForwardVector(), -axis);

		Direction.X = axis;
		Direction.Y = 0;
	}
}

void ARPGCharacter::MoveRight(float axis)
{
	if (axis > 0) {
		float controllerYaw = CameraBoom->GetRelativeRotation().Yaw + 90.0f;
		GetWorld()->GetFirstPlayerController()->SetControlRotation(FRotator(0, controllerYaw, 0));
		AddMovementInput(GetActorForwardVector(), axis);

		Direction.X = axis;
		Direction.Y = 0;
	}
}

void ARPGCharacter::SprintDrain()
{
	int stamina = Stats->GetStatValue("STA");
	stamina -= SprintCost;
	Stats->SetStatValue("STA", stamina);

	UpdateStaminaUI(stamina);

	if (stamina < SprintCost) {
		GetCharacterMovement()->MaxWalkSpeed = WalkSpeed;
		GetWorldTimerManager().ClearTimer(SprintDrainTimerHandle);
		IsSprinting = false;
	}
}

void ARPGCharacter::RegenerateStamina()
{
	if (!IsSprinting && Stats) {
		int stamina = Stats->GetStatValue("STA");

		if (stamina != Stats->GetStatValue("MaxSTA")) {
			stamina += StaminaRecoveryRate * Stats->GetStatValue("STR");

			int maxStamina = Stats->GetStatValue("MaxSTA");
			if (stamina >= maxStamina)
				stamina = maxStamina;

			UpdateStaminaUI(stamina);
			Stats->SetStatValue("STA", stamina);
		}
	}
}

void ARPGCharacter::UpdateStaminaUI(int stamina, int maxStamina)
{
	if (RPGHUD)
	{
		UStaminaBarWidget* staminaBar = RPGHUD->StaminaBarWidget;

		if (staminaBar) {
			staminaBar->SetStamina(stamina);
			if (maxStamina != 0)
				staminaBar->SetMaxStamina(maxStamina);
			staminaBar->ResizeStaminaBar((float)stamina / Stats->GetStatValue("MaxSTA"));
		}
	}
}

void ARPGCharacter::ClearTimer()
{
	GetWorldTimerManager().ClearTimer(RegenerateStaminaTimerHandle);
}

void ARPGCharacter::RestartTimer()
{
	GetWorld()->GetTimerManager().SetTimer(RegenerateStaminaTimerHandle, this, &ARPGCharacter::RegenerateStamina, 0.5f, true);
}

void ARPGCharacter::Jump()
{
	jumpCount++;

	if (jumpCount <= MaxJumpCount) {
		FVector velocity = FVector(0, 0, GetCharacterMovement()->JumpZVelocity);
		LaunchCharacter(velocity, false, true);
	}
}

void ARPGCharacter::Landed(const FHitResult& Hit)
{
	jumpCount = 0;
}

void ARPGCharacter::Walk()
{
	GetCharacterMovement()->MaxWalkSpeed = WalkSpeed;
	GetWorldTimerManager().ClearTimer(SprintDrainTimerHandle);
	IsSprinting = false;
}

void ARPGCharacter::Sprint()
{
	if (Stats->GetStatValue("STA") >= SprintCost)
	{
		GetCharacterMovement()->MaxWalkSpeed = RunSpeed;
		IsSprinting = true;

		GetWorldTimerManager().SetTimer(SprintDrainTimerHandle, this, &ARPGCharacter::SprintDrain, 0.5f, true, 0.0f);
	}
}

void ARPGCharacter::OnLockBoxBeginOverlap(UPrimitiveComponent*
	OverlappedComp, AActor* OtherActor, UPrimitiveComponent* OtherComp,
	int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult)
{
	IHealth* health = Cast<IHealth>(OtherActor);

	if (health && !health->IsDead()) {
		ILock* target = Cast<ILock>(OtherActor);

		if (target)
		{
			// Show lock widget
			target->ShowLocked(true);
			currentTarget = OtherActor;
		}
	}

	if (!InteractableActor) {
		IInteractable* interactable = Cast<IInteractable>(OtherActor);

		if (interactable)
			interactable->ShowInteractableIcon(true, this);
	}

}

void ARPGCharacter::OnLockBoxEndOverlap(UPrimitiveComponent*
	OverlappedComp, AActor* OtherActor, UPrimitiveComponent* OtherComp,
	int32 OtherBodyIndex)
{
	ILock* target = Cast<ILock>(OtherActor);

	if (target)
	{
		target->ShowLocked(false);
		currentTarget = NULL;
	}

	IInteractable* interactable = Cast<IInteractable>(OtherActor);
	if (interactable)
		interactable->ShowInteractableIcon(false);
}

