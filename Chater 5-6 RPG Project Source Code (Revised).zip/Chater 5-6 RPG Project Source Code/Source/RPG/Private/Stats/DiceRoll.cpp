/**********************************************************************************
Copyright � 2022 Dr. Chihming Chiu - All Right Reserved

The source code contained within this file is for the book,
UNREAL ENGINE 5 RPG DEVELOPMENT with C++ and Blueprint,
and is intended for educational purposes only.

Feel free to use this code provided you include the above copyright notice.
The code is provided "AS IS", without warranty of any kind, express or implied.
***********************************************************************************/
#include "Stats/DiceRoll.h"

UDiceRoll::UDiceRoll()
{
	// Default is the normal die with 6 faces, roll once
	Rolls = 1;
	Faces = 6;
	Modifier = 0;
}

UDiceRoll::UDiceRoll(int rolls, int faces, int modifier)
{
	Rolls = rolls;
	Faces = faces;
	Modifier = modifier;
}

int UDiceRoll::Die(int rolls, int faces, int modifier)
{
	int total = 0;

	for (int i = 1; i <= rolls; i++)
	{
		total += FMath::RandRange(1, faces);
	}

	return total + modifier;
}

int UDiceRoll::Roll()
{
	return Die(Rolls, Faces, Modifier);
}
