/**********************************************************************************
Copyright � 2022 Dr. Chihming Chiu - All Right Reserved

The source code contained within this file is for the book,
UNREAL ENGINE 5 RPG DEVELOPMENT with C++ and Blueprint,
and is intended for educational purposes only.

Feel free to use this code provided you include the above copyright notice.
The code is provided "AS IS", without warranty of any kind, express or implied.
***********************************************************************************/
#include "NPC/Enemy.h"
#include "UI/HealthBarWidget.h"
#include "UI/DamageTextWidget.h"
#include "Kismet/KismetSystemLibrary.h"

AEnemy::AEnemy()
{
    HealthBar =
        CreateDefaultSubobject<UWidgetComponent>(TEXT("HealthBarWidget"));
    HealthBar->SetupAttachment(RootComponent);

	LockWidget =
		CreateDefaultSubobject<UWidgetComponent>(TEXT("LockWidget"));
	LockWidget->SetupAttachment(RootComponent);

	DamageText =
		CreateDefaultSubobject<UWidgetComponent>(TEXT("DamageTextWidget"));
	DamageText->SetupAttachment(RootComponent);

	DisintegrationFX =	CreateDefaultSubobject<UNiagaraComponent>(TEXT("DisintegrationFX"));
	DisintegrationFX->SetupAttachment(GetMesh());
}

void AEnemy::ActivateDisintegration(bool activate, FVector location)
{
	if (activate) {
		if (DisintegrationFX)
			DisintegrationFX->Activate(true);

		CurveFTimeline.PlayFromStart();
	}
	else {
		if (DisintegrationFX)
			DisintegrationFX->Deactivate();
	}
}

void AEnemy::TimelineProgress(float value)
{
	if (DisintegrationFX) {
		if (value >= EndDisintegrationRadius) {
			if (MPCInst)
				MPCInst->SetScalarParameterValue(FName(HardnessParameterName), 1);
			ActivateDisintegration(false);

			if(!Respawnable)
				Destroy();
			else {
				Respawn();

				if (MPCInst)
					MPCInst->SetScalarParameterValue(FName(RadiusParameterName), 0);
			}
		}
		else {
			DisintegrationFX->SetNiagaraVariableFloat(RadiusParameterName, value);
			if (MPCInst)
				MPCInst->SetScalarParameterValue(FName(RadiusParameterName), value);
		}
	}
}

void AEnemy::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	CurveFTimeline.TickTimeline(DeltaTime);
}

void AEnemy::BeginPlay()
{
	Super::BeginPlay();

	if (CurveFloat) {
		FOnTimelineFloat TimelineProgress;
		TimelineProgress.BindUFunction(this, FName("TimelineProgress"));
		CurveFTimeline.AddInterpFloat(CurveFloat, TimelineProgress);
		CurveFTimeline.SetLooping(false);
	}

	if (MaterialParameterCollectionAsset) {
		MPCInst = GetWorld()->GetParameterCollectionInstance(
			MaterialParameterCollectionAsset);
	}
}

void AEnemy::ResizeHealthBar(int hp)
{
	UHealthBarWidget* healthBar = Cast<UHealthBarWidget>(HealthBar->GetUserWidgetObject());

	if (healthBar) {
		int maxhp = Stats->GetStatValue("MaxHP");

		if (maxhp != 0)
			healthBar->ResizeHealthBar(hp / (float)maxhp);
	}
}

void AEnemy::ApplyDamage(int damageValue, AActor* causer)
{
	UDamageTextWidget* damageText = Cast<UDamageTextWidget>(	DamageText->GetUserWidgetObject());

	if (damageText) {
		damageText->SetDamageText(FText::FromString(FString::FromInt(damageValue)));
		damageText->PlayFloatingTextAnimation();
	}

	/****************************************************************************************/
	// Note: The following nullptr checking code is added after the book is published!
	if (Stats) {
	/****************************************************************************************/
		int hp = Stats->GetStatValue("HP");
		hp -= damageValue;

		if (hp <= 0) {
			hp = 0;
			isDead = true;

			PlayDeathMontage();
		}
		else
			PlayGetHitMontage();

		ResizeHealthBar(hp);
		Stats->SetStatValue("HP", hp);
	/****************************************************************************************/
	}     // if (Stats)
	/****************************************************************************************/
}


void AEnemy::PlayDeathMontage()
{
	if (DeathMontages.Num() != 0)
	{
		ActivateDisintegration(true);

		int num = FMath::RandRange(0, DeathMontages.Num() - 1);
		PlayAnimMontage(DeathMontages[num]);
	}
}

void AEnemy::PlayGetHitMontage()
{
	if (GetHitMontages.Num() != 0)
	{
		int num = FMath::RandRange(0, GetHitMontages.Num() - 1);
		PlayAnimMontage(GetHitMontages[num]);
	}
}

bool AEnemy::IsDead()
{
	return isDead;
}

void AEnemy::ShowLocked(bool visible)
{
	if (LockWidget)
		LockWidget->SetVisibility(visible);
}

FVector AEnemy::CalculateRespawnLocation()
{
	FVector center = GetActorLocation();
	FVector respawnPos(0, 0, center.Z);

	float radius = FMath::RandRange(300.0, 1350.0);
	float angle = FMath::RandRange(0.0, 360.0);

	respawnPos.X = center.X + radius * FMath::Cos(angle);
	respawnPos.Y = center.Y + radius * FMath::Sin(angle);

	FVector traceStart = FVector(respawnPos.X, respawnPos.Y, respawnPos.Z + 100);
	FVector traceEnd = FVector(respawnPos.X, respawnPos.Y, respawnPos.Z - 120);
	FHitResult hitResult(ForceInit);

	TArray<AActor*> actorsToIgnore;
	actorsToIgnore.Add(this);

	bool isHit = UKismetSystemLibrary::LineTraceSingle(GetWorld(), traceStart, traceEnd, 
		UEngineTypes::ConvertToTraceType(ECC_Visibility), false, actorsToIgnore, EDrawDebugTrace::Persistent, hitResult, true,
		FLinearColor::Red, FLinearColor::Blue, 1.0f);

	if (isHit)
		return hitResult.ImpactPoint + FVector(0, 0, 10);
	else
		return center;
}

void AEnemy::Respawn()
{
}

